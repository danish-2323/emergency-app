/**
 * RoadSoS — MapScreen.js (Placeholder)
 * Full implementation in the corresponding Task
 */
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import COLORS from '../constants/colors';

export default function MapScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>MapScreen</Text>
      <Text style={styles.sub}>Full implementation coming in the next Task</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center' },
  text: { color: COLORS.textPrimary, fontSize: 22, fontWeight: '700' },
  sub: { color: COLORS.textSecondary, fontSize: 13, marginTop: 8 },
});
