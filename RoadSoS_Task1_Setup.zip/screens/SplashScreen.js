/**
 * RoadSoS — SplashScreen.js
 * 
 * Responsibilities:
 *  1. Show app logo + animated pulse
 *  2. Request location permission
 *  3. Pre-load cached nearby data (OfflineService)
 *  4. Navigate to Main after ready (or 3s max)
 */

import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Easing,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Location from 'expo-location';

import COLORS from '../constants/colors';
import { APP_INFO } from '../constants/config';

export default function SplashScreen({ navigation }) {
  // Animation values
  const logoScale = useRef(new Animated.Value(0.6)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const pulseScale = useRef(new Animated.Value(1)).current;
  const pulseOpacity = useRef(new Animated.Value(0.6)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const taglineOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // 1. Entrance animation
    Animated.sequence([
      // Logo appears
      Animated.parallel([
        Animated.timing(logoOpacity, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.spring(logoScale, {
          toValue: 1,
          tension: 80,
          friction: 6,
          useNativeDriver: true,
        }),
      ]),
      // Text fades in
      Animated.timing(textOpacity, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true,
      }),
      // Tagline fades in
      Animated.timing(taglineOpacity, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true,
      }),
    ]).start();

    // 2. Pulsing ring animation (loops)
    const startPulse = () => {
      Animated.loop(
        Animated.sequence([
          Animated.parallel([
            Animated.timing(pulseScale, {
              toValue: 1.6,
              duration: 1000,
              easing: Easing.out(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(pulseOpacity, {
              toValue: 0,
              duration: 1000,
              useNativeDriver: true,
            }),
          ]),
          Animated.parallel([
            Animated.timing(pulseScale, {
              toValue: 1,
              duration: 0,
              useNativeDriver: true,
            }),
            Animated.timing(pulseOpacity, {
              toValue: 0.5,
              duration: 0,
              useNativeDriver: true,
            }),
          ]),
        ])
      ).start();
    };

    startPulse();

    // 3. Init app: request permissions + preload cache
    initApp();
  }, []);

  const initApp = async () => {
    try {
      // Request location permission (non-blocking for splash)
      const { status } = await Location.requestForegroundPermissionsAsync();
      // We don't block navigation on permission — handle gracefully in HomeScreen
    } catch (e) {
      // Permission request failed — handle in HomeScreen
    }

    // Give animations at least 2.5s to run before navigating
    await new Promise(resolve => setTimeout(resolve, 2800));

    // Navigate to main app
    navigation.replace('Main');
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Background subtle radial hint */}
      <View style={styles.bgGlow} />

      {/* SOS Logo Circle */}
      <View style={styles.logoWrapper}>
        {/* Pulsing ring behind logo */}
        <Animated.View
          style={[
            styles.pulseRing,
            {
              transform: [{ scale: pulseScale }],
              opacity: pulseOpacity,
            },
          ]}
        />

        {/* Main logo circle */}
        <Animated.View
          style={[
            styles.logoCircle,
            {
              opacity: logoOpacity,
              transform: [{ scale: logoScale }],
            },
          ]}
        >
          <Text style={styles.logoText}>SOS</Text>
        </Animated.View>
      </View>

      {/* App Name */}
      <Animated.Text style={[styles.appName, { opacity: textOpacity }]}>
        RoadSoS
      </Animated.Text>

      {/* Tagline */}
      <Animated.Text style={[styles.tagline, { opacity: taglineOpacity }]}>
        Emergency Help in the Golden Hour
      </Animated.Text>

      {/* Hackathon credit */}
      <Animated.Text style={[styles.credit, { opacity: taglineOpacity }]}>
        {APP_INFO.HACKATHON}
      </Animated.Text>

      {/* Loading dots at bottom */}
      <Animated.View style={[styles.loadingRow, { opacity: taglineOpacity }]}>
        <LoadingDot delay={0} />
        <LoadingDot delay={200} />
        <LoadingDot delay={400} />
      </Animated.View>
    </SafeAreaView>
  );
}

// Animated loading dot
function LoadingDot({ delay }) {
  const opacity = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    setTimeout(() => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(opacity, {
            toValue: 1,
            duration: 400,
            useNativeDriver: true,
          }),
          Animated.timing(opacity, {
            toValue: 0.3,
            duration: 400,
            useNativeDriver: true,
          }),
        ])
      ).start();
    }, delay);
  }, []);

  return (
    <Animated.View style={[styles.dot, { opacity }]} />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    alignItems: 'center',
    justifyContent: 'center',
  },

  bgGlow: {
    position: 'absolute',
    width: 400,
    height: 400,
    borderRadius: 200,
    backgroundColor: COLORS.primaryGlow,
    top: '50%',
    left: '50%',
    marginTop: -200,
    marginLeft: -200,
    // Note: React Native doesn't support CSS radial-gradient natively;
    // use expo-linear-gradient or leave as a subtle flat glow
  },

  logoWrapper: {
    width: 160,
    height: 160,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
  },

  pulseRing: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 80,
    borderWidth: 3,
    borderColor: COLORS.primary,
    backgroundColor: 'transparent',
  },

  logoCircle: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 12,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 24,
  },

  logoText: {
    color: '#FFFFFF',
    fontSize: 42,
    fontWeight: '900',
    letterSpacing: 4,
  },

  appName: {
    color: COLORS.textPrimary,
    fontSize: 40,
    fontWeight: '800',
    letterSpacing: 2,
    marginBottom: 10,
  },

  tagline: {
    color: COLORS.textSecondary,
    fontSize: 14,
    fontWeight: '500',
    letterSpacing: 0.5,
    textAlign: 'center',
    paddingHorizontal: 40,
    marginBottom: 8,
  },

  credit: {
    color: COLORS.textMuted,
    fontSize: 11,
    letterSpacing: 0.3,
    textAlign: 'center',
    position: 'absolute',
    bottom: 60,
  },

  loadingRow: {
    flexDirection: 'row',
    gap: 8,
    position: 'absolute',
    bottom: 40,
  },

  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: COLORS.primary,
  },
});
