/**
 * RoadSoS — HomeScreen.js (Placeholder)
 * Full implementation: Task 5
 */
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import COLORS from '../constants/colors';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>🏠 HomeScreen</Text>
      <Text style={styles.sub}>Full implementation in Task 5</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center' },
  text: { color: COLORS.textPrimary, fontSize: 24, fontWeight: '700' },
  sub: { color: COLORS.textSecondary, fontSize: 14, marginTop: 8 },
});
