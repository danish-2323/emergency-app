/**
 * RoadSoS App Configuration
 * Central config for all API endpoints, timeouts, and feature flags
 */

// ─── BACKEND API ────────────────────────────────────────────────────────────
// Change BASE_URL to your Flask server IP when running locally
// For production: replace with your deployed server URL
export const API = {
  BASE_URL: 'http://192.168.1.100:5000',   // Local Flask dev server
  // BASE_URL: 'https://roadsos-api.onrender.com', // Production (Render free tier)

  ENDPOINTS: {
    SEARCH: '/api/search',
    SEVERITY: '/api/severity',
    CHAT: '/api/chat',
    EMERGENCY_NUMBERS: '/api/emergency-numbers',
    HEALTH: '/api/health',
  },

  TIMEOUT_MS: 8000,        // 8s timeout — critical app, fail fast
  RETRY_ATTEMPTS: 2,       // Retry once before falling back to cache
};

// ─── OPENSTREETMAP / OVERPASS ────────────────────────────────────────────────
export const OSM = {
  OVERPASS_URL: 'https://overpass-api.de/api/interpreter',
  NOMINATIM_URL: 'https://nominatim.openstreetmap.org',
  TILE_URL: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',

  // Fallback Overpass mirrors (in case primary is down)
  OVERPASS_MIRRORS: [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
  ],

  DEFAULT_RADIUS_KM: 10,     // Search radius in km
  MAX_RADIUS_KM: 50,         // Max allowed search radius
  MAX_RESULTS: 20,           // Cap results per service type
};

// ─── SERVICE TYPES ──────────────────────────────────────────────────────────
export const SERVICE_TYPES = {
  HOSPITAL: 'hospital',
  POLICE: 'police',
  AMBULANCE: 'ambulance',
  TOWING: 'towing',
  PUNCTURE: 'puncture',
};

// OSM tags used to identify each service type in Overpass queries
export const OSM_TAGS = {
  hospital: [
    'amenity=hospital',
    'amenity=clinic',
    'healthcare=hospital',
    'amenity=doctors',
  ],
  police: [
    'amenity=police',
  ],
  ambulance: [
    'emergency=ambulance_station',
    'amenity=ambulance_station',
    'emergency=medical_service',
  ],
  towing: [
    'service=vehicle:towing',
    'amenity=car_repair',
    'shop=car_repair',
    'emergency=towing_service',
  ],
  puncture: [
    'shop=tyres',
    'shop=bicycle',        // Often does punctures
    'amenity=bicycle_repair_station',
  ],
};

// ─── SEVERITY LEVELS ────────────────────────────────────────────────────────
export const SEVERITY = {
  CRITICAL: 'CRITICAL',
  MODERATE: 'MODERATE',
  MINOR: 'MINOR',
};

export const SEVERITY_CONFIG = {
  CRITICAL: {
    label: 'CRITICAL',
    emoji: '🔴',
    color: '#FF2D2D',
    bgColor: 'rgba(255,45,45,0.12)',
    recommendation: 'Call ambulance IMMEDIATELY. Do not move the injured person.',
    serviceType: SERVICE_TYPES.HOSPITAL,
    callAmbulance: true,
  },
  MODERATE: {
    label: 'MODERATE',
    emoji: '🟡',
    color: '#FFB300',
    bgColor: 'rgba(255,179,0,0.12)',
    recommendation: 'Go to nearest hospital. Keep the person calm and still.',
    serviceType: SERVICE_TYPES.HOSPITAL,
    callAmbulance: false,
  },
  MINOR: {
    label: 'MINOR',
    emoji: '🟢',
    color: '#00C853',
    bgColor: 'rgba(0,200,83,0.12)',
    recommendation: 'Contact police and get vehicle towed if needed.',
    serviceType: SERVICE_TYPES.POLICE,
    callAmbulance: false,
  },
};

// ─── OFFLINE CACHE ──────────────────────────────────────────────────────────
export const CACHE = {
  KEY_PREFIX: 'roadsos_cache_',
  EXPIRY_HOURS: 24,                          // Cache valid for 24 hours
  EXPIRY_MS: 24 * 60 * 60 * 1000,
  LOCATION_ROUND_DIGITS: 2,                  // Round lat/lon for cache key (≈1km accuracy)
  SETTINGS_KEY: 'roadsos_settings',
  GUARDIANS_KEY: 'roadsos_guardians',
  LANGUAGE_KEY: 'roadsos_language',
  COUNTRY_KEY: 'roadsos_country',
};

// ─── VOICE / SPEECH ─────────────────────────────────────────────────────────
export const VOICE = {
  // Keywords that trigger emergency SOS (English + Hindi)
  TRIGGER_KEYWORDS: [
    'help', 'sos', 'accident', 'emergency', 'crash', 'hurt',
    'bachao',    // Hindi: save me
    'madad',     // Hindi: help
    'ambulance', 'hospital', 'police',
  ],

  SPEECH_LANGUAGE: 'en-IN',    // Indian English TTS
  SPEECH_RATE: 0.9,            // Slightly slower for clarity
  SPEECH_PITCH: 1.0,

  // TTS templates (replace {name} {distance} etc at runtime)
  TTS_NEAREST: 'Nearest {type} is {name}, {distance} kilometers away.',
  TTS_CALLING: 'Calling {name} now.',
  TTS_SOS_TRIGGERED: 'Emergency SOS triggered. Finding nearest services.',
  TTS_OFFLINE: 'No internet. Loading last saved emergency contacts.',
};

// ─── CRASH DETECTION ────────────────────────────────────────────────────────
export const CRASH = {
  G_FORCE_THRESHOLD: 3.0,     // 3G deceleration triggers detection
  CONFIRM_TIMEOUT_MS: 30000,  // 30 seconds to respond before auto-SOS
  CHECK_INTERVAL_MS: 100,     // Accelerometer poll interval
};

// ─── SMS / ALERT TEMPLATES ──────────────────────────────────────────────────
export const SMS = {
  EMERGENCY_TEMPLATE: (name, address, lat, lon) =>
    `🚨 EMERGENCY ALERT from ${name}\n\nI had a road accident at:\n📍 ${address}\n\nMy live location:\nhttps://maps.google.com/?q=${lat},${lon}\n\nPlease help immediately!\n\n— Sent by RoadSoS App`,

  GUARDIAN_TEMPLATE: (name, address, lat, lon, time) =>
    `🚨 SOS from ${name}\n\nAccident detected at:\n${address}\n\nLocation: https://maps.google.com/?q=${lat},${lon}\n\nTime: ${time}\n\n— RoadSoS Emergency App`,

  WHATSAPP_BASE_URL: 'whatsapp://send?text=',
};

// ─── SUPPORTED COUNTRIES ────────────────────────────────────────────────────
export const COUNTRIES = [
  { code: 'IN', name: 'India', flag: '🇮🇳', phone: '+91' },
  { code: 'US', name: 'United States', flag: '🇺🇸', phone: '+1' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', phone: '+44' },
  { code: 'AE', name: 'UAE', flag: '🇦🇪', phone: '+971' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬', phone: '+65' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺', phone: '+61' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', phone: '+1' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', phone: '+49' },
];

// ─── SUPPORTED LANGUAGES ────────────────────────────────────────────────────
export const LANGUAGES = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' },
];

// ─── APP INFO ────────────────────────────────────────────────────────────────
export const APP_INFO = {
  NAME: 'RoadSoS',
  TAGLINE: 'Emergency Help in the Golden Hour',
  VERSION: '1.0.0',
  HACKATHON: 'Road Safety Hackathon 2026 — IIT Madras',
  TEAM: 'CoERS, RBG Labs',
  DATA_SOURCE: 'OpenStreetMap contributors (ODbL)',
  SUPPORT_EMAIL: 'roadsos@example.com',
};

// ─── UI CONSTANTS ────────────────────────────────────────────────────────────
export const UI = {
  SOS_BUTTON_SIZE: 200,
  MIN_TAP_TARGET: 48,
  BORDER_RADIUS: {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
    full: 9999,
  },
  SPACING: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  ANIMATION: {
    SOS_PULSE_DURATION: 1200,  // ms
    TRANSITION_FAST: 200,
    TRANSITION_NORMAL: 350,
  },
};

export default {
  API,
  OSM,
  SERVICE_TYPES,
  OSM_TAGS,
  SEVERITY,
  SEVERITY_CONFIG,
  CACHE,
  VOICE,
  CRASH,
  SMS,
  COUNTRIES,
  LANGUAGES,
  APP_INFO,
  UI,
};
