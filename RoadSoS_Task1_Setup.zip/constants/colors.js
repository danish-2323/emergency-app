/**
 * RoadSoS Design System — Color Constants
 * Emergency-grade dark UI with high-contrast critical alerts
 */

export const COLORS = {
  // === BACKGROUNDS ===
  background: '#0A0A0A',         // Main app background (near-black)
  backgroundCard: '#1A1A1A',     // Card / surface background
  backgroundElevated: '#242424', // Slightly elevated surface (modals, sheets)
  backgroundInput: '#111111',    // Input field background

  // === PRIMARY EMERGENCY RED ===
  primary: '#FF2D2D',            // SOS button, critical alerts
  primaryDark: '#CC1F1F',        // Pressed/active state
  primaryLight: '#FF5555',       // Lighter red (highlights)
  primaryGlow: 'rgba(255,45,45,0.25)', // Glow ring around SOS button

  // === SECONDARY SAFE GREEN ===
  secondary: '#00C853',          // Safe state, call buttons, success
  secondaryDark: '#00A844',      // Pressed green
  secondaryLight: '#33D36B',     // Light green highlights
  secondaryGlow: 'rgba(0,200,83,0.2)', // Glow for call buttons

  // === SEVERITY LEVELS ===
  severityCritical: '#FF2D2D',   // 🔴 CRITICAL
  severityModerate: '#FFB300',   // 🟡 MODERATE
  severityMinor: '#00C853',      // 🟢 MINOR
  severityCriticalBg: 'rgba(255,45,45,0.12)',
  severityModerateBg: 'rgba(255,179,0,0.12)',
  severityMinorBg: 'rgba(0,200,83,0.12)',

  // === SERVICE TYPE COLORS (map pins + cards) ===
  serviceHospital: '#FF2D2D',    // 🏥 Red
  servicePolice: '#2979FF',      // 👮 Blue
  serviceAmbulance: '#FF6D00',   // 🚑 Orange
  serviceTowing: '#78909C',      // 🚗 Slate grey
  servicePuncture: '#AB47BC',    // 🔧 Purple
  serviceHospitalBg: 'rgba(255,45,45,0.15)',
  servicePoliceBg: 'rgba(41,121,255,0.15)',
  serviceAmbulanceBg: 'rgba(255,109,0,0.15)',
  serviceTowingBg: 'rgba(120,144,156,0.15)',
  servicePunctureBg: 'rgba(171,71,188,0.15)',

  // === TEXT ===
  textPrimary: '#FFFFFF',        // Main text
  textSecondary: '#AAAAAA',      // Subtitles, metadata
  textMuted: '#666666',          // Placeholder, disabled
  textInverse: '#0A0A0A',        // Text on light/colored backgrounds
  textDanger: '#FF5252',         // Inline error/warning text
  textSuccess: '#69F0AE',        // Inline success text

  // === CHAT BUBBLES ===
  chatUserBubble: '#1E5C38',     // User message — dark green
  chatBotBubble: '#1E1E1E',      // Bot message — dark grey
  chatUserText: '#FFFFFF',
  chatBotText: '#EEEEEE',
  chatTimestamp: '#666666',
  chatBackground: '#0D0D0D',

  // === BORDERS & DIVIDERS ===
  border: '#2A2A2A',             // Subtle card border
  borderStrong: '#3A3A3A',       // Visible divider
  borderDanger: 'rgba(255,45,45,0.4)',

  // === STATUS ===
  online: '#00E676',             // Green dot — online
  offline: '#FF5252',            // Red dot — offline
  loading: '#FFB300',            // Yellow — loading
  inactive: '#555555',           // Grey — inactive/disabled

  // === MAP ===
  mapUserLocation: '#2979FF',    // Blue dot for user
  mapUserLocationBorder: '#FFFFFF',
  mapUserLocationGlow: 'rgba(41,121,255,0.3)',

  // === OVERLAYS ===
  overlay: 'rgba(0,0,0,0.7)',    // Modal/bottom sheet backdrop
  overlayLight: 'rgba(0,0,0,0.4)',

  // === NAVIGATION ===
  navBackground: '#111111',
  navBorder: '#1E1E1E',
  navActive: '#FF2D2D',
  navInactive: '#555555',

  // === GRADIENTS (use with LinearGradient) ===
  gradientSOS: ['#FF2D2D', '#CC0000'],
  gradientCall: ['#00C853', '#007E33'],
  gradientDark: ['#1A1A1A', '#0A0A0A'],
  gradientAlert: ['rgba(255,45,45,0.0)', 'rgba(255,45,45,0.15)'],
};

// Semantic aliases — use these in components for clarity
export const SEMANTIC = {
  danger: COLORS.primary,
  safe: COLORS.secondary,
  warning: COLORS.severityModerate,
  info: COLORS.servicePolice,
  surface: COLORS.backgroundCard,
  bg: COLORS.background,
};

export default COLORS;
