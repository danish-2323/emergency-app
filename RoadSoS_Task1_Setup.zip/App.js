/**
 * RoadSoS — App.js
 * Root component with navigation setup, global providers, and splash handling
 * 
 * Navigation Structure:
 *   RootStack
 *   └── SplashScreen (no tab bar)
 *   └── MainTabs
 *       ├── HomeScreen
 *       ├── ChatScreen
 *       ├── MapScreen
 *       ├── ServicesScreen
 *       └── SettingsScreen
 *   └── SeverityScreen (modal, accessible from Home + Chat)
 *   └── FirstAidScreen (modal)
 *   └── EvidenceScreen (modal)
 */

import React, { useEffect, useState, useRef } from 'react';
import {
  StatusBar,
  Platform,
  View,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

import COLORS from './constants/colors';
import { UI } from './constants/config';

// ─── Screen Imports ──────────────────────────────────────────────────────────
// Uncomment each as you build them (Task 2–12)
import SplashScreen from './screens/SplashScreen';
import HomeScreen from './screens/HomeScreen';
import ChatScreen from './screens/ChatScreen';
import MapScreen from './screens/MapScreen';
import ServicesScreen from './screens/ServicesScreen';
import SeverityScreen from './screens/SeverityScreen';
import SettingsScreen from './screens/SettingsScreen';
// import FirstAidScreen from './screens/FirstAidScreen';   // Task: FirstAid
// import EvidenceScreen from './screens/EvidenceScreen';   // Task: Evidence
// import SafeRouteScreen from './screens/SafeRouteScreen'; // Task: SafeRoute

// ─── Navigators ──────────────────────────────────────────────────────────────
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// ─── Bottom Tab Navigator ────────────────────────────────────────────────────
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.navInactive,
        tabBarLabelStyle: styles.tabLabel,
        tabBarItemStyle: styles.tabItem,
        // Tab icon factory
        tabBarIcon: ({ focused, color, size }) => {
          return <TabIcon routeName={route.name} focused={focused} color={color} />;
        },
      })}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{ tabBarLabel: 'Home' }}
      />
      <Tab.Screen
        name="Chat"
        component={ChatScreen}
        options={{ tabBarLabel: 'AI Help' }}
      />
      <Tab.Screen
        name="Map"
        component={MapScreen}
        options={{ tabBarLabel: 'Map' }}
      />
      <Tab.Screen
        name="Services"
        component={ServicesScreen}
        options={{ tabBarLabel: 'Services' }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ tabBarLabel: 'Settings' }}
      />
    </Tab.Navigator>
  );
}

// ─── Tab Icon Component ──────────────────────────────────────────────────────
function TabIcon({ routeName, focused, color }) {
  const scale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (focused) {
      Animated.sequence([
        Animated.timing(scale, { toValue: 1.25, duration: 150, useNativeDriver: true }),
        Animated.timing(scale, { toValue: 1.0, duration: 150, useNativeDriver: true }),
      ]).start();
    }
  }, [focused]);

  const iconMap = {
    Home: focused ? 'home' : 'home-outline',
    Chat: focused ? 'chatbubble-ellipses' : 'chatbubble-ellipses-outline',
    Map: focused ? 'map' : 'map-outline',
    Services: focused ? 'list' : 'list-outline',
    Settings: focused ? 'settings' : 'settings-outline',
  };

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      {routeName === 'Home' && focused ? (
        // Home tab gets a special red indicator ring when active
        <View style={styles.activeHomeTab}>
          <Ionicons name={iconMap[routeName]} size={22} color={color} />
        </View>
      ) : (
        <Ionicons name={iconMap[routeName] || 'ellipse-outline'} size={22} color={color} />
      )}
    </Animated.View>
  );
}

// ─── Offline Banner ───────────────────────────────────────────────────────────
function OfflineBanner({ visible }) {
  const translateY = useRef(new Animated.Value(-50)).current;

  useEffect(() => {
    Animated.timing(translateY, {
      toValue: visible ? 0 : -50,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, [visible]);

  return (
    <Animated.View style={[styles.offlineBanner, { transform: [{ translateY }] }]}>
      <Ionicons name="cloud-offline-outline" size={14} color="#fff" />
      <Text style={styles.offlineBannerText}>  OFFLINE MODE — Using cached data</Text>
    </Animated.View>
  );
}

// ─── Root App ────────────────────────────────────────────────────────────────
export default function App() {
  const [isOffline, setIsOffline] = useState(false);
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    // Listen for network changes
    // NetInfo would go here — simplified for now
    // NetInfo.addEventListener(state => setIsOffline(!state.isConnected));
    setAppReady(true);
  }, []);

  if (!appReady) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar
          barStyle="light-content"
          backgroundColor={COLORS.background}
          translucent={false}
        />

        {/* Offline indicator banner — sits above everything */}
        <OfflineBanner visible={isOffline} />

        <NavigationContainer
          theme={{
            dark: true,
            colors: {
              primary: COLORS.primary,
              background: COLORS.background,
              card: COLORS.navBackground,
              text: COLORS.textPrimary,
              border: COLORS.navBorder,
              notification: COLORS.primary,
            },
          }}
        >
          <Stack.Navigator
            initialRouteName="Splash"
            screenOptions={{
              headerShown: false,
              cardStyle: { backgroundColor: COLORS.background },
              // Smooth push animation
              cardStyleInterpolator: ({ current, layouts }) => ({
                cardStyle: {
                  opacity: current.progress,
                  transform: [
                    {
                      translateY: current.progress.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              }),
            }}
          >
            {/* Splash — initial loading screen */}
            <Stack.Screen
              name="Splash"
              component={SplashScreen}
              options={{ animationEnabled: false }}
            />

            {/* Main tabbed interface */}
            <Stack.Screen
              name="Main"
              component={MainTabs}
            />

            {/* Modal screens — slide up from bottom */}
            <Stack.Screen
              name="Severity"
              component={SeverityScreen}
              options={{
                presentation: 'modal',
                cardStyleInterpolator: ({ current, layouts }) => ({
                  cardStyle: {
                    transform: [
                      {
                        translateY: current.progress.interpolate({
                          inputRange: [0, 1],
                          outputRange: [layouts.screen.height, 0],
                        }),
                      },
                    ],
                  },
                }),
              }}
            />

            {/* First Aid — opens as modal over chat/home */}
            {/* <Stack.Screen
              name="FirstAid"
              component={FirstAidScreen}
              options={{ presentation: 'modal' }}
            /> */}

            {/* Evidence capture */}
            {/* <Stack.Screen
              name="Evidence"
              component={EvidenceScreen}
              options={{ presentation: 'modal' }}
            /> */}
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: COLORS.navBackground,
    borderTopColor: COLORS.navBorder,
    borderTopWidth: 1,
    height: Platform.OS === 'ios' ? 85 : 65,
    paddingBottom: Platform.OS === 'ios' ? 20 : 8,
    paddingTop: 8,
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },

  tabLabel: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.3,
    marginTop: 2,
  },

  tabItem: {
    paddingTop: 4,
  },

  activeHomeTab: {
    backgroundColor: COLORS.primaryGlow,
    borderRadius: 10,
    padding: 4,
  },

  offlineBanner: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: COLORS.offline,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    zIndex: 9999,
    elevation: 9999,
  },

  offlineBannerText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});
